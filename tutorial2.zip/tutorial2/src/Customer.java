public class Customer {
    String name;
    int age;
    float money;

    boolean admitted;
    public Customer(String initName){
        name = initName;
        age = 0;
        money = 0.0f;
        admitted = false;
    }

    public Customer(String initName, int initAge){
        name = initName;
        age = initAge;
        money = 0.0f;
        admitted = false;
    }

    public Customer(String initName, int initAge, float initMoney){
        name = initName;
        age = initAge;
        money = initMoney;
        admitted = false;
    }
    public Customer(){
        name = "Ben";
        age = 18;
        money = 2.0f;
        admitted = false;
    }

    public float computeFee(){
        float fee;
        if (this.age <= 3){
            fee = 0;
        } else if (this.age >= 4 && this.age <= 17) {
            fee = 8.5f;
        } else if (this.age >= 18 && this.age <= 65) {
            fee = 12.75f;
        }
        else {
            fee = 12.75f * 0.5f;
        }
        return fee;
    }

    /* Assumption: Spending a negative amount is no longer spending by definition, so the transaction is cancelled
    with no changes to the amount of money the customer has.
     */

    // Added condition: Spending 0 will still count as spending since free admission will still grant access

    public boolean spend(float amount){
        if (this.money < amount || amount < 0) return false;
        else{
            this.money -= amount;
            return true;
        }
    }

    public boolean hasMoreMoneyThan(Customer c){
        if (this.money > c.money) return true;
        return false;
    }

    public void payAdmission(){
        if (this.spend(this.computeFee())) this.admitted = true;
    }

    public String toString(){
        if (admitted == false){
            return "Customer " + name + ": a " + age + " year old with $" + money + " who has not been admitted";
        }
        else{
            return "Customer " + name + ": a " + age + " year old with $" + money + " who has been admitted";
        }

    }
}

