public class CustomerTestProgram {
    public static void main(String args[]) {
        Customer c;
        c = new Customer("Bob");
        c.age = 27;
        c.money = 50;

        Customer d;
        d = new Customer("Ben");
        d.age = 18;
        d.money = 2.35f;

        System.out.println(c.name);
        System.out.println(c.age);
        System.out.println(c.money);

        System.out.println();

        System.out.println(d.name);
        System.out.println(d.age);
        System.out.println(d.money);
    }

}
